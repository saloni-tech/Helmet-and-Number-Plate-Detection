import os

class Config:
    """Base configuration"""
    SECRET_KEY = os.environ.get('SECRET_KEY') or 'dev-secret-key-change-in-production'
    UPLOAD_FOLDER = 'uploads'
    MAX_CONTENT_LENGTH = 50 * 1024 * 1024  # 50MB
    
    # Model paths
    HELMET_MODEL_PATH = 'models/helmet_detection.pt'
    PLATE_MODEL_PATH = 'models/plate_detection.pt'
    
    # Detection parameters
    HELMET_CONFIDENCE_THRESHOLD = 0.4
    PLATE_CONFIDENCE_THRESHOLD = 0.3
    
    # Database (if needed)
    SQLALCHEMY_DATABASE_URI = os.environ.get('DATABASE_URL') or 'sqlite:///detections.db'
    SQLALCHEMY_TRACK_MODIFICATIONS = False

class DevelopmentConfig(Config):
    """Development configuration"""
    DEBUG = True

class ProductionConfig(Config):
    """Production configuration"""
    DEBUG = False

config = {
    'development': DevelopmentConfig,
    'production': ProductionConfig,
    'default': DevelopmentConfig
}
