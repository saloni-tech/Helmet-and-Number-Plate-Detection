from flask import Flask, request, jsonify
from flask_cors import CORS
import cv2
import numpy as np
from ultralytics import YOLO
import os
from werkzeug.utils import secure_filename
import base64
from PIL import Image
import io
import re

app = Flask(__name__)
CORS(app)

# Configuration
UPLOAD_FOLDER = 'uploads'
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'mp4', 'avi'}
MAX_CONTENT_LENGTH = 50 * 1024 * 1024  # 50MB

app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
app.config['MAX_CONTENT_LENGTH'] = MAX_CONTENT_LENGTH

# Create upload folder if it doesn't exist
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

# Initialize YOLO models
# Note: You'll need to train or download pre-trained models
# For demo purposes, we'll use YOLOv8 base model and adapt it
helmet_model = None
plate_model = None

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def load_models():
    """Load YOLO models for helmet and number plate detection"""
    global helmet_model, plate_model
    
    # For production, replace with your trained models
    # helmet_model = YOLO('helmet_model.pt')
    # plate_model = YOLO('plate_model.pt')
    
    # For demo, we'll use base YOLOv8n model
    try:
        helmet_model = YOLO('yolov8n.pt')
        plate_model = YOLO('yolov8n.pt')
        print("Models loaded successfully")
    except Exception as e:
        print(f"Error loading models: {e}")
        # Models will be downloaded on first use

def detect_helmet_and_plate(image_path):
    """
    Detect helmets and number plates in an image
    Returns detection results with bounding boxes
    """
    # Load image
    image = cv2.imread(image_path)
    original_image = image.copy()
    
    results = {
        'helmets': [],
        'plates': [],
        'violations': [],
        'annotated_image': None
    }
    
    # Helmet detection
    try:
        helmet_results = helmet_model(image, conf=0.4)
        
        for result in helmet_results:
            boxes = result.boxes
            for box in boxes:
                cls = int(box.cls[0])
                conf = float(box.conf[0])
                x1, y1, x2, y2 = map(int, box.xyxy[0])
                
                # For demo: detect persons (class 0) as potential riders
                # In production, you'd have specific helmet/no-helmet classes
                if cls == 0:  # Person detected
                    results['helmets'].append({
                        'bbox': [x1, y1, x2, y2],
                        'confidence': conf,
                        'has_helmet': conf > 0.6  # Simplified logic
                    })
                    
                    # Draw bounding box
                    color = (0, 255, 0) if conf > 0.6 else (0, 0, 255)
                    cv2.rectangle(image, (x1, y1), (x2, y2), color, 2)
                    label = f"Helmet: {conf:.2f}" if conf > 0.6 else f"No Helmet: {conf:.2f}"
                    cv2.putText(image, label, (x1, y1-10), 
                              cv2.FONT_HERSHEY_SIMPLEX, 0.5, color, 2)
    except Exception as e:
        print(f"Helmet detection error: {e}")
    
    # Number plate detection
    try:
        plate_results = plate_model(image, conf=0.3)
        
        for result in plate_results:
            boxes = result.boxes
            for box in boxes:
                cls = int(box.cls[0])
                conf = float(box.conf[0])
                x1, y1, x2, y2 = map(int, box.xyxy[0])
                
                # For demo: detect any rectangular object as potential plate
                # In production, you'd have a specific plate detection model
                if cls in [2, 3, 5, 7]:  # Car, motorcycle, bus, truck
                    results['plates'].append({
                        'bbox': [x1, y1, x2, y2],
                        'confidence': conf,
                        'plate_number': 'DETECTED'  # OCR would go here
                    })
                    
                    # Draw bounding box
                    cv2.rectangle(image, (x1, y1), (x2, y2), (255, 0, 0), 2)
                    cv2.putText(image, f"Plate: {conf:.2f}", (x1, y1-10),
                              cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 0, 0), 2)
    except Exception as e:
        print(f"Plate detection error: {e}")
    
    # Check for violations (no helmet detected)
    for helmet in results['helmets']:
        if not helmet['has_helmet']:
            results['violations'].append({
                'type': 'no_helmet',
                'bbox': helmet['bbox'],
                'confidence': helmet['confidence']
            })
    
    # Convert annotated image to base64
    _, buffer = cv2.imencode('.jpg', image)
    img_base64 = base64.b64encode(buffer).decode('utf-8')
    results['annotated_image'] = f"data:image/jpeg;base64,{img_base64}"
    
    return results

@app.route('/api/health', methods=['GET'])
def health_check():
    """Health check endpoint"""
    return jsonify({
        'status': 'healthy',
        'models_loaded': helmet_model is not None and plate_model is not None
    })

@app.route('/api/detect', methods=['POST'])
def detect():
    """
    Main detection endpoint
    Accepts image upload and returns detection results
    """
    if 'file' not in request.files:
        return jsonify({'error': 'No file provided'}), 400
    
    file = request.files['file']
    
    if file.filename == '':
        return jsonify({'error': 'No file selected'}), 400
    
    if not allowed_file(file.filename):
        return jsonify({'error': 'Invalid file type'}), 400
    
    try:
        # Save uploaded file
        filename = secure_filename(file.filename)
        filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        file.save(filepath)
        
        # Perform detection
        results = detect_helmet_and_plate(filepath)
        
        # Add summary statistics
        results['summary'] = {
            'total_helmets_detected': len(results['helmets']),
            'helmets_worn': sum(1 for h in results['helmets'] if h['has_helmet']),
            'violations': len(results['violations']),
            'plates_detected': len(results['plates'])
        }
        
        # Clean up uploaded file
        os.remove(filepath)
        
        return jsonify(results)
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/detect-base64', methods=['POST'])
def detect_base64():
    """
    Detection endpoint that accepts base64 encoded images
    """
    data = request.get_json()
    
    if 'image' not in data:
        return jsonify({'error': 'No image data provided'}), 400
    
    try:
        # Decode base64 image
        image_data = data['image']
        if 'base64,' in image_data:
            image_data = image_data.split('base64,')[1]
        
        image_bytes = base64.b64decode(image_data)
        image = Image.open(io.BytesIO(image_bytes))
        
        # Save temporarily
        temp_path = os.path.join(app.config['UPLOAD_FOLDER'], 'temp.jpg')
        image.save(temp_path)
        
        # Perform detection
        results = detect_helmet_and_plate(temp_path)
        
        # Add summary
        results['summary'] = {
            'total_helmets_detected': len(results['helmets']),
            'helmets_worn': sum(1 for h in results['helmets'] if h['has_helmet']),
            'violations': len(results['violations']),
            'plates_detected': len(results['plates'])
        }
        
        # Clean up
        os.remove(temp_path)
        
        return jsonify(results)
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/stats', methods=['GET'])
def get_stats():
    """
    Get detection statistics
    This is a demo endpoint - in production, you'd track this in a database
    """
    return jsonify({
        'total_detections': 0,
        'total_violations': 0,
        'accuracy': 0.95,
        'processing_time_avg': 0.8
    })

if __name__ == '__main__':
    print("Loading models...")
    load_models()
    print("Starting Flask server...")
    app.run(debug=True, host='0.0.0.0', port=5000)
