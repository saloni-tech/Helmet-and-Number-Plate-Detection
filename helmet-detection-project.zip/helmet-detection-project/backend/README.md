# Helmet and Number Plate Detection - Backend

Flask-based REST API for detecting helmets and number plates using YOLOv8.

## Features

- Real-time helmet detection
- Number plate detection and recognition
- Violation detection (riders without helmets)
- RESTful API endpoints
- Support for image and video processing
- Base64 image support

## Installation

1. Create a virtual environment:
```bash
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate
```

2. Install dependencies:
```bash
pip install -r requirements.txt
```

3. Download or train YOLOv8 models:
   - Place helmet detection model as `models/helmet_detection.pt`
   - Place plate detection model as `models/plate_detection.pt`
   - Or use the default YOLOv8n model (will auto-download)

## Usage

Start the server:
```bash
python app.py
```

The API will be available at `http://localhost:5000`

## API Endpoints

### Health Check
```
GET /api/health
```

### Detect from File Upload
```
POST /api/detect
Content-Type: multipart/form-data

Body:
- file: Image file (jpg, png, jpeg)
```

### Detect from Base64
```
POST /api/detect-base64
Content-Type: application/json

Body:
{
  "image": "data:image/jpeg;base64,..."
}
```

### Get Statistics
```
GET /api/stats
```

## Response Format

```json
{
  "helmets": [
    {
      "bbox": [x1, y1, x2, y2],
      "confidence": 0.95,
      "has_helmet": true
    }
  ],
  "plates": [
    {
      "bbox": [x1, y1, x2, y2],
      "confidence": 0.87,
      "plate_number": "ABC1234"
    }
  ],
  "violations": [
    {
      "type": "no_helmet",
      "bbox": [x1, y1, x2, y2],
      "confidence": 0.82
    }
  ],
  "annotated_image": "data:image/jpeg;base64,...",
  "summary": {
    "total_helmets_detected": 2,
    "helmets_worn": 1,
    "violations": 1,
    "plates_detected": 1
  }
}
```

## Model Training

To train custom models:

1. Prepare dataset with annotations
2. Use YOLOv8 training:
```bash
yolo train data=helmet_data.yaml model=yolov8n.pt epochs=100
yolo train data=plate_data.yaml model=yolov8n.pt epochs=100
```

3. Place trained models in `models/` directory

## Environment Variables

- `SECRET_KEY`: Flask secret key
- `DATABASE_URL`: Database connection string (if using database)

## Production Deployment

For production, use a WSGI server:

```bash
pip install gunicorn
gunicorn -w 4 -b 0.0.0.0:5000 app:app
```

## Notes

- The demo uses YOLOv8n base model
- For production, train specific helmet and plate detection models
- Add OCR integration for plate number recognition (e.g., EasyOCR, Tesseract)
- Consider adding database for storing detection history
