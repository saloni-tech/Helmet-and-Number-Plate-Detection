# Helmet and Number Plate Detection - Frontend

Modern, responsive web interface for the helmet and number plate detection system.

## Features

- Drag-and-drop image upload
- Real-time detection visualization
- Detailed results with bounding boxes
- Violation tracking
- Statistics dashboard
- Responsive design for mobile and desktop
- Modern UI with animations

## Setup

### Option 1: Direct File Access

Simply open `index.html` in your browser:

```bash
# From the frontend directory
open index.html
# or
firefox index.html
# or
google-chrome index.html
```

### Option 2: Local Server

For better CORS handling, use a local server:

```bash
# Python 3
python -m http.server 8000

# Node.js (if you have it)
npx http-server -p 8000

# Or any other local server
```

Then visit: `http://localhost:8000`

## Usage

1. Make sure the backend is running at `http://localhost:5000`
2. Open the frontend
3. Upload an image by clicking or dragging
4. Click "Analyze Image" to run detection
5. View results with annotated image and statistics

## API Configuration

The frontend expects the backend API at `http://localhost:5000/api`

To change this, edit the `API_URL` constant in `index.html`:

```javascript
const API_URL = 'http://your-backend-url:port/api';
```

## Browser Compatibility

- Chrome/Edge (recommended)
- Firefox
- Safari
- Modern mobile browsers

## Features Overview

### Upload Section
- Drag and drop support
- Click to browse
- File preview before detection
- Support for JPG, PNG formats

### Results Section
- Annotated image with bounding boxes
- Statistics cards:
  - Total riders detected
  - Helmets worn
  - Violations count
  - Number plates detected
- Detailed list of detections
- Color-coded violations

### Visual Design
- Dark theme with neon accents
- Animated gradients
- Responsive grid layout
- Smooth transitions
- Modern glassmorphism effects

## Customization

### Colors

Edit CSS variables in the `<style>` section:

```css
:root {
    --primary: #00d4ff;      /* Primary accent */
    --secondary: #7c3aed;     /* Secondary accent */
    --danger: #ef4444;        /* Violations */
    --success: #10b981;       /* Success states */
    /* ... */
}
```

### Fonts

Current fonts:
- Display: Outfit (Google Fonts)
- Monospace: JetBrains Mono (Google Fonts)

Change in the `<link>` tag in the HTML head.

## Troubleshooting

### "Detection failed" error
- Ensure backend is running on port 5000
- Check CORS settings in backend
- Verify API_URL is correct

### Images not uploading
- Check file size (max 50MB)
- Verify file format (JPG, PNG only)
- Check browser console for errors

### UI not displaying correctly
- Clear browser cache
- Try a different browser
- Check browser console for errors

## Performance

- Optimized for images up to 50MB
- Client-side preview generation
- Efficient base64 encoding
- Minimal dependencies (vanilla JavaScript)

## Future Enhancements

- Video upload and processing
- Real-time webcam detection
- Batch processing
- Detection history
- Export reports (PDF/CSV)
- User authentication
- Database integration
