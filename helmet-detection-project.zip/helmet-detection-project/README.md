# 🏍️ Helmet and Number Plate Detection System

An AI-powered system for detecting helmet usage and number plates using YOLOv8 deep learning models. Built with Flask backend and modern web frontend.

## 🌟 Features

- **Helmet Detection**: Identifies riders and checks for helmet compliance
- **Number Plate Detection**: Detects and locates vehicle number plates
- **Violation Detection**: Automatically flags riders without helmets
- **Real-time Processing**: Fast detection with YOLOv8
- **Modern UI**: Responsive web interface with drag-and-drop upload
- **RESTful API**: Easy integration with other systems
- **Visual Results**: Annotated images with bounding boxes

## 🏗️ Architecture

```
helmet-detection-project/
├── backend/
│   ├── app.py                 # Flask application
│   ├── config.py              # Configuration
│   ├── requirements.txt       # Python dependencies
│   └── README.md
├── frontend/
│   ├── index.html            # Web interface
│   └── README.md
└── README.md
```

## 🚀 Quick Start

### Prerequisites

- Python 3.8 or higher
- pip (Python package manager)
- Modern web browser
- (Optional) CUDA-enabled GPU for faster processing

### Backend Setup

1. Navigate to backend directory:
```bash
cd backend
```

2. Create virtual environment:
```bash
python -m venv venv

# On Linux/Mac:
source venv/bin/activate

# On Windows:
venv\Scripts\activate
```

3. Install dependencies:
```bash
pip install -r requirements.txt
```

4. Run the server:
```bash
python app.py
```

The API will be available at `http://localhost:5000`

### Frontend Setup

1. Navigate to frontend directory:
```bash
cd frontend
```

2. Open in browser:
```bash
# Direct file access
open index.html

# Or use a local server (recommended)
python -m http.server 8000
# Then visit http://localhost:8000
```

## 📖 Usage Guide

### Step 1: Start Backend
```bash
cd backend
python app.py
```

You should see:
```
Loading models...
Models loaded successfully
Starting Flask server...
 * Running on http://0.0.0.0:5000
```

### Step 2: Open Frontend
Open `frontend/index.html` in your browser or navigate to `http://localhost:8000`

### Step 3: Upload and Analyze
1. Click the upload zone or drag an image
2. Click "Analyze Image"
3. View detection results with statistics

## 🔧 API Documentation

### Endpoints

#### Health Check
```http
GET /api/health
```

Response:
```json
{
  "status": "healthy",
  "models_loaded": true
}
```

#### Detect from File
```http
POST /api/detect
Content-Type: multipart/form-data

Body: file=<image-file>
```

#### Detect from Base64
```http
POST /api/detect-base64
Content-Type: application/json

Body:
{
  "image": "data:image/jpeg;base64,..."
}
```

#### Response Format
```json
{
  "helmets": [
    {
      "bbox": [x1, y1, x2, y2],
      "confidence": 0.95,
      "has_helmet": true
    }
  ],
  "plates": [
    {
      "bbox": [x1, y1, x2, y2],
      "confidence": 0.87,
      "plate_number": "DETECTED"
    }
  ],
  "violations": [
    {
      "type": "no_helmet",
      "bbox": [x1, y1, x2, y2],
      "confidence": 0.82
    }
  ],
  "annotated_image": "data:image/jpeg;base64,...",
  "summary": {
    "total_helmets_detected": 2,
    "helmets_worn": 1,
    "violations": 1,
    "plates_detected": 1
  }
}
```

## 🎯 Model Training

### Preparing Dataset

1. **Helmet Detection Dataset**:
   - Collect images of riders with and without helmets
   - Annotate with bounding boxes
   - Classes: `person_with_helmet`, `person_without_helmet`

2. **Number Plate Dataset**:
   - Collect vehicle images with visible plates
   - Annotate plate locations
   - Classes: `license_plate`

### Training with YOLOv8

```bash
# Install ultralytics
pip install ultralytics

# Train helmet model
yolo train data=helmet_data.yaml model=yolov8n.pt epochs=100 imgsz=640

# Train plate model
yolo train data=plate_data.yaml model=yolov8n.pt epochs=100 imgsz=640
```

### Dataset YAML Format

```yaml
# helmet_data.yaml
path: /path/to/dataset
train: images/train
val: images/val

names:
  0: person_with_helmet
  1: person_without_helmet
```

## 🔬 Advanced Features

### OCR Integration for Plate Recognition

Add OCR to read plate numbers:

```python
# Install easyocr
pip install easyocr

# In app.py
import easyocr
reader = easyocr.Reader(['en'])

def read_plate(plate_image):
    result = reader.readtext(plate_image)
    return result[0][1] if result else "UNKNOWN"
```

### Database Integration

Track detections over time:

```python
# Install SQLAlchemy
pip install flask-sqlalchemy

# Add to app.py
from flask_sqlalchemy import SQLAlchemy

db = SQLAlchemy(app)

class Detection(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)
    violations = db.Column(db.Integer)
    plate_number = db.Column(db.String(20))
```

### Video Processing

Process video streams:

```python
import cv2

def process_video(video_path):
    cap = cv2.VideoCapture(video_path)
    
    while cap.isOpened():
        ret, frame = cap.read()
        if not ret:
            break
        
        # Run detection on frame
        results = helmet_model(frame)
        # Process results...
    
    cap.release()
```

## 🚦 Production Deployment

### Using Gunicorn

```bash
pip install gunicorn
gunicorn -w 4 -b 0.0.0.0:5000 app:app
```

### Using Docker

```dockerfile
# Dockerfile
FROM python:3.9-slim

WORKDIR /app
COPY requirements.txt .
RUN pip install -r requirements.txt

COPY . .
CMD ["gunicorn", "-w", "4", "-b", "0.0.0.0:5000", "app:app"]
```

### Environment Variables

```bash
export SECRET_KEY=your-secret-key
export DATABASE_URL=postgresql://user:pass@localhost/db
```

## 🛠️ Troubleshooting

### Issue: Models not loading
**Solution**: YOLOv8 will auto-download on first run. Ensure internet connection.

### Issue: CUDA out of memory
**Solution**: Reduce batch size or use CPU mode:
```python
helmet_model = YOLO('yolov8n.pt', device='cpu')
```

### Issue: CORS errors
**Solution**: Check Flask-CORS configuration:
```python
CORS(app, resources={r"/api/*": {"origins": "*"}})
```

### Issue: Slow detection
**Solutions**:
- Use GPU acceleration
- Use smaller model (yolov8n instead of yolov8x)
- Reduce image resolution
- Enable model optimization

## 📊 Performance Optimization

1. **GPU Acceleration**: Use CUDA-enabled GPU
2. **Model Selection**: yolov8n (fastest) vs yolov8x (most accurate)
3. **Image Preprocessing**: Resize images before detection
4. **Batch Processing**: Process multiple images at once
5. **Model Quantization**: Use TensorRT for production

## 🤝 Contributing

Contributions welcome! Areas for improvement:
- Better helmet classification models
- OCR integration for plate reading
- Real-time video processing
- Mobile app integration
- Dashboard analytics

## 📝 License

This project is for educational purposes. Ensure compliance with local regulations when deploying for surveillance.

## 🙏 Acknowledgments

- YOLOv8 by Ultralytics
- Flask framework
- OpenCV community

## 📧 Support

For issues and questions:
- Check the troubleshooting section
- Review API documentation
- Open an issue with details

## 🔮 Future Roadmap

- [ ] Real-time video stream processing
- [ ] Mobile application (React Native)
- [ ] Cloud deployment guides (AWS, GCP)
- [ ] Advanced analytics dashboard
- [ ] Multi-camera support
- [ ] Automated violation reporting
- [ ] Integration with traffic management systems

---

**Note**: This is a demo implementation using base YOLO models. For production use, train specific models on helmet and plate datasets for better accuracy.
