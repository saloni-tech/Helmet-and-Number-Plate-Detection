#!/bin/bash

# Helmet Detection System - Quick Setup Script

echo "========================================="
echo "Helmet Detection System Setup"
echo "========================================="
echo ""

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Check Python version
echo "Checking Python version..."
python_version=$(python3 --version 2>&1 | awk '{print $2}')
required_version="3.8"

if [ "$(printf '%s\n' "$required_version" "$python_version" | sort -V | head -n1)" = "$required_version" ]; then 
    echo -e "${GREEN}✓ Python $python_version found${NC}"
else
    echo -e "${RED}✗ Python 3.8 or higher is required${NC}"
    exit 1
fi

# Setup backend
echo ""
echo "========================================="
echo "Setting up Backend..."
echo "========================================="
cd backend

# Create virtual environment
echo "Creating virtual environment..."
python3 -m venv venv

# Activate virtual environment
echo "Activating virtual environment..."
source venv/bin/activate

# Install dependencies
echo "Installing Python dependencies..."
pip install --upgrade pip
pip install -r requirements.txt

if [ $? -eq 0 ]; then
    echo -e "${GREEN}✓ Backend dependencies installed${NC}"
else
    echo -e "${RED}✗ Failed to install backend dependencies${NC}"
    exit 1
fi

# Create necessary directories
echo "Creating directories..."
mkdir -p uploads models

echo -e "${GREEN}✓ Backend setup complete${NC}"

# Return to project root
cd ..

# Setup frontend
echo ""
echo "========================================="
echo "Frontend Setup"
echo "========================================="
echo -e "${GREEN}✓ Frontend is ready (no build required)${NC}"

# Final instructions
echo ""
echo "========================================="
echo "Setup Complete!"
echo "========================================="
echo ""
echo "To start the application:"
echo ""
echo "1. Start the backend:"
echo "   cd backend"
echo "   source venv/bin/activate"
echo "   python app.py"
echo ""
echo "2. Open frontend:"
echo "   Open frontend/index.html in your browser"
echo "   or run: python -m http.server 8000 (in frontend directory)"
echo ""
echo "Note: On first run, YOLOv8 models will be downloaded automatically."
echo ""
echo "For custom models, place them in backend/models/ directory:"
echo "  - helmet_detection.pt"
echo "  - plate_detection.pt"
echo ""
echo -e "${YELLOW}Press any key to start the backend now, or Ctrl+C to exit...${NC}"
read -n 1 -s

# Start backend
echo ""
echo "Starting backend server..."
cd backend
source venv/bin/activate
python app.py
