# 🚀 Deployment Guide - Helmet Detection System

Complete guide for deploying the Helmet and Number Plate Detection System in various environments.

## Table of Contents
1. [Local Development](#local-development)
2. [Docker Deployment](#docker-deployment)
3. [Cloud Deployment](#cloud-deployment)
4. [Production Considerations](#production-considerations)

---

## 🏠 Local Development

### Prerequisites
- Python 3.8+
- 4GB RAM minimum (8GB recommended)
- Modern web browser
- (Optional) NVIDIA GPU with CUDA for faster processing

### Quick Start

**Linux/Mac:**
```bash
chmod +x setup.sh
./setup.sh
```

**Windows:**
```batch
setup.bat
```

### Manual Setup

1. **Backend Setup:**
```bash
cd backend
python -m venv venv
source venv/bin/activate  # Windows: venv\Scripts\activate
pip install -r requirements.txt
python app.py
```

2. **Frontend Setup:**
```bash
cd frontend
python -m http.server 8000
# Visit http://localhost:8000
```

---

## 🐳 Docker Deployment

### Using Docker Compose (Recommended)

1. **Install Docker and Docker Compose**
   - [Docker Desktop](https://www.docker.com/products/docker-desktop) (Windows/Mac)
   - [Docker Engine](https://docs.docker.com/engine/install/) (Linux)

2. **Build and Run:**
```bash
docker-compose up --build
```

3. **Access:**
   - Frontend: http://localhost:8080
   - Backend API: http://localhost:5000

4. **Stop:**
```bash
docker-compose down
```

### Individual Container Deployment

**Backend Only:**
```bash
cd backend
docker build -t helmet-detection-backend .
docker run -p 5000:5000 helmet-detection-backend
```

**With GPU Support:**
```bash
docker run --gpus all -p 5000:5000 helmet-detection-backend
```

---

## ☁️ Cloud Deployment

### AWS Deployment

#### EC2 Instance Setup

1. **Launch EC2 Instance:**
   - AMI: Ubuntu 20.04 LTS
   - Instance Type: t3.medium (minimum), g4dn.xlarge (with GPU)
   - Storage: 30GB minimum
   - Security Group: Open ports 22, 5000, 8080

2. **Connect and Install:**
```bash
ssh -i your-key.pem ubuntu@your-instance-ip

# Update system
sudo apt update && sudo apt upgrade -y

# Install Docker
curl -fsSL https://get.docker.com -o get-docker.sh
sudo sh get-docker.sh
sudo usermod -aG docker ubuntu

# Install Docker Compose
sudo curl -L "https://github.com/docker/compose/releases/latest/download/docker-compose-$(uname -s)-$(uname -m)" -o /usr/local/bin/docker-compose
sudo chmod +x /usr/local/bin/docker-compose

# Clone and deploy
git clone <your-repo>
cd helmet-detection-project
docker-compose up -d
```

3. **Setup HTTPS (Optional but Recommended):**
```bash
# Install Nginx
sudo apt install nginx certbot python3-certbot-nginx -y

# Configure Nginx
sudo nano /etc/nginx/sites-available/helmet-detection

# Add SSL certificate
sudo certbot --nginx -d your-domain.com
```

#### AWS Lambda + API Gateway (Serverless)

```python
# lambda_function.py
import json
import base64
from detection import detect_helmet_and_plate

def lambda_handler(event, context):
    # Decode base64 image
    image_data = base64.b64decode(event['body'])
    
    # Run detection
    results = detect_helmet_and_plate(image_data)
    
    return {
        'statusCode': 200,
        'headers': {
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*'
        },
        'body': json.dumps(results)
    }
```

### Google Cloud Platform

#### Cloud Run Deployment

1. **Install Google Cloud SDK:**
```bash
curl https://sdk.cloud.google.com | bash
gcloud init
```

2. **Build and Deploy:**
```bash
cd backend
gcloud builds submit --tag gcr.io/YOUR_PROJECT_ID/helmet-detection
gcloud run deploy helmet-detection \
  --image gcr.io/YOUR_PROJECT_ID/helmet-detection \
  --platform managed \
  --region us-central1 \
  --allow-unauthenticated \
  --memory 4Gi \
  --cpu 2
```

#### App Engine Deployment

```yaml
# app.yaml
runtime: python39
env: standard
instance_class: F4_1G

automatic_scaling:
  target_cpu_utilization: 0.65
  min_instances: 1
  max_instances: 10

resources:
  cpu: 2
  memory_gb: 4
  disk_size_gb: 10
```

```bash
gcloud app deploy
```

### Microsoft Azure

#### Container Instances

```bash
# Login to Azure
az login

# Create resource group
az group create --name helmet-detection-rg --location eastus

# Create container instance
az container create \
  --resource-group helmet-detection-rg \
  --name helmet-detection-app \
  --image your-registry/helmet-detection:latest \
  --cpu 2 \
  --memory 4 \
  --ports 5000 8080 \
  --dns-name-label helmet-detection
```

---

## 🔒 Production Considerations

### Security

1. **API Authentication:**
```python
from flask_jwt_extended import JWTManager, jwt_required

app.config['JWT_SECRET_KEY'] = 'your-secret-key'
jwt = JWTManager(app)

@app.route('/api/detect', methods=['POST'])
@jwt_required()
def detect():
    # Your detection code
    pass
```

2. **Rate Limiting:**
```python
from flask_limiter import Limiter

limiter = Limiter(
    app,
    key_func=lambda: request.remote_addr,
    default_limits=["100 per hour"]
)

@app.route('/api/detect')
@limiter.limit("10 per minute")
def detect():
    pass
```

3. **Environment Variables:**
```bash
# .env file
SECRET_KEY=your-production-secret-key
DATABASE_URL=postgresql://user:pass@host:5432/db
ALLOWED_ORIGINS=https://yourdomain.com
MAX_UPLOAD_SIZE=52428800
```

### Performance Optimization

1. **Model Optimization:**
```python
# Use TensorRT for NVIDIA GPUs
from ultralytics import YOLO

model = YOLO('helmet_model.pt')
model.export(format='engine')  # TensorRT
model = YOLO('helmet_model.engine')
```

2. **Caching:**
```python
from flask_caching import Cache

cache = Cache(app, config={
    'CACHE_TYPE': 'redis',
    'CACHE_REDIS_URL': 'redis://localhost:6379/0'
})

@cache.memoize(timeout=300)
def get_stats():
    # Expensive computation
    pass
```

3. **Load Balancing:**
```nginx
upstream backend {
    least_conn;
    server backend1:5000;
    server backend2:5000;
    server backend3:5000;
}

server {
    location /api/ {
        proxy_pass http://backend;
    }
}
```

### Monitoring

1. **Prometheus Metrics:**
```python
from prometheus_flask_exporter import PrometheusMetrics

metrics = PrometheusMetrics(app)

@metrics.counter('detections_total', 'Total detections')
def detect():
    pass
```

2. **Logging:**
```python
import logging

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s %(levelname)s: %(message)s',
    handlers=[
        logging.FileHandler('app.log'),
        logging.StreamHandler()
    ]
)
```

3. **Health Checks:**
```python
@app.route('/health')
def health():
    return {
        'status': 'healthy',
        'timestamp': datetime.utcnow().isoformat(),
        'version': '1.0.0'
    }
```

### Database Integration

```python
from flask_sqlalchemy import SQLAlchemy
from datetime import datetime

db = SQLAlchemy(app)

class Detection(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)
    image_path = db.Column(db.String(255))
    helmets_detected = db.Column(db.Integer)
    violations = db.Column(db.Integer)
    plates_detected = db.Column(db.Integer)
    confidence_avg = db.Column(db.Float)

# Create tables
with app.app_context():
    db.create_all()
```

### Backup Strategy

```bash
#!/bin/bash
# backup.sh

# Backup database
pg_dump helmet_detection > backup_$(date +%Y%m%d).sql

# Backup models
tar -czf models_backup_$(date +%Y%m%d).tar.gz models/

# Upload to S3
aws s3 cp backup_$(date +%Y%m%d).sql s3://your-bucket/backups/
aws s3 cp models_backup_$(date +%Y%m%d).tar.gz s3://your-bucket/backups/

# Cleanup old backups (keep 30 days)
find . -name "backup_*.sql" -mtime +30 -delete
```

### CI/CD Pipeline

```yaml
# .github/workflows/deploy.yml
name: Deploy

on:
  push:
    branches: [ main ]

jobs:
  deploy:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v2
      
      - name: Build and push Docker image
        run: |
          docker build -t helmet-detection:${{ github.sha }} .
          docker push helmet-detection:${{ github.sha }}
      
      - name: Deploy to production
        run: |
          kubectl set image deployment/helmet-detection \
            app=helmet-detection:${{ github.sha }}
```

---

## 📊 Performance Benchmarks

| Configuration | Processing Time | Throughput |
|--------------|-----------------|------------|
| CPU (4 cores) | ~2.5s per image | 24 img/min |
| GPU (T4) | ~0.3s per image | 200 img/min |
| GPU (V100) | ~0.15s per image | 400 img/min |

---

## 🆘 Troubleshooting

### Issue: High Memory Usage
**Solution:** Reduce batch size or image resolution
```python
results = model(image, imgsz=320)  # Reduced from 640
```

### Issue: Slow Cold Starts
**Solution:** Keep models loaded in memory
```python
# Use model warmup
model.predict(np.zeros((640, 640, 3)))
```

### Issue: CORS Errors
**Solution:** Configure proper CORS headers
```python
CORS(app, resources={
    r"/api/*": {
        "origins": ["https://yourdomain.com"],
        "methods": ["GET", "POST"],
        "allow_headers": ["Content-Type"]
    }
})
```

---

## 📚 Additional Resources

- [YOLOv8 Documentation](https://docs.ultralytics.com/)
- [Flask Production Deployment](https://flask.palletsprojects.com/en/2.3.x/deploying/)
- [Docker Best Practices](https://docs.docker.com/develop/dev-best-practices/)
- [AWS EC2 User Guide](https://docs.aws.amazon.com/ec2/)

---

**Last Updated:** February 2024
