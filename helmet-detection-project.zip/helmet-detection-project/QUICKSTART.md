# 🚀 Quick Start Guide

Get the Helmet and Number Plate Detection System running in 5 minutes!

## ⚡ Fastest Way to Start

### Option 1: Automatic Setup (Recommended)

**Linux/Mac:**
```bash
chmod +x setup.sh
./setup.sh
```

**Windows:**
```batch
setup.bat
```

The script will:
1. Check Python installation
2. Create virtual environment
3. Install all dependencies
4. Start the backend server automatically

### Option 2: Manual Setup (3 steps)

**Step 1: Backend**
```bash
cd backend
python -m venv venv
source venv/bin/activate  # Windows: venv\Scripts\activate
pip install -r requirements.txt
python app.py
```

**Step 2: Frontend**
```bash
cd frontend
# Option A: Direct file
open index.html

# Option B: Local server (recommended)
python -m http.server 8000
# Then visit: http://localhost:8000
```

**Step 3: Test**
1. Open frontend in browser
2. Upload a test image
3. Click "Analyze Image"
4. View detection results!

### Option 3: Docker (One Command)

```bash
docker-compose up
```

Access at:
- Frontend: http://localhost:8080
- Backend API: http://localhost:5000

## ✅ Verify Installation

Check if backend is running:
```bash
curl http://localhost:5000/api/health
```

Expected response:
```json
{
  "status": "healthy",
  "models_loaded": true
}
```

## 🎯 First Detection

1. **Open Frontend**: Navigate to `http://localhost:8000` or open `frontend/index.html`

2. **Upload Image**: 
   - Click upload zone or drag & drop
   - Supported: JPG, PNG (max 50MB)

3. **Analyze**: Click "🔍 Analyze Image"

4. **View Results**:
   - Annotated image with bounding boxes
   - Detection statistics
   - Violation alerts (if any)

## 📁 Project Structure

```
helmet-detection-project/
├── backend/              # Flask API server
│   ├── app.py           # Main application
│   ├── requirements.txt # Python dependencies
│   └── models/          # Place trained models here
├── frontend/            # Web interface
│   └── index.html       # Single-page app
├── setup.sh            # Linux/Mac setup
├── setup.bat           # Windows setup
└── README.md           # Full documentation
```

## 🔧 Common Issues

### "Module not found" error
```bash
# Make sure venv is activated
source backend/venv/bin/activate  # Linux/Mac
backend\venv\Scripts\activate     # Windows

# Reinstall dependencies
pip install -r requirements.txt
```

### "Port already in use"
```bash
# Change port in app.py (last line)
app.run(debug=True, host='0.0.0.0', port=5001)  # Changed to 5001
```

### "CORS error"
- Make sure backend is running first
- Check API_URL in frontend/index.html matches backend port

### Models downloading slowly
- First run downloads YOLOv8 models (~6MB)
- Subsequent runs use cached models
- For custom models, place in `backend/models/`

## 🎓 Next Steps

1. **Train Custom Models**: See `DEPLOYMENT.md` for training instructions
2. **Add Features**: OCR for plate recognition, video processing
3. **Deploy**: AWS, GCP, Azure guides in `DEPLOYMENT.md`
4. **Customize**: Modify detection thresholds in `backend/config.py`

## 📚 Documentation

- `README.md` - Full project documentation
- `DEPLOYMENT.md` - Production deployment guide
- `backend/README.md` - Backend API reference
- `frontend/README.md` - Frontend guide

## 💡 Tips

- Use GPU for 10x faster detection (CUDA required)
- Reduce image size for faster processing
- Train custom models on your specific use case
- Add database for tracking violations over time

## 🆘 Need Help?

1. Check the troubleshooting section in `README.md`
2. Verify all dependencies are installed
3. Check backend logs for error messages
4. Ensure Python 3.8+ is installed

## 🎉 You're All Set!

The system is now ready to detect helmets and number plates. Upload an image and see it in action!

---

**Quick Commands:**

```bash
# Start backend
cd backend && source venv/bin/activate && python app.py

# Start frontend
cd frontend && python -m http.server 8000

# Docker
docker-compose up

# Check health
curl http://localhost:5000/api/health
```

Happy detecting! 🏍️📸
